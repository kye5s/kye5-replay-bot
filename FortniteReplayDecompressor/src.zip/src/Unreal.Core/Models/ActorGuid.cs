﻿namespace Unreal.Core.Models;

/// <summary>
/// Just a wrapper class for <see cref="NetworkGUID"/>
/// </summary>
public class ActorGuid : NetworkGUID
{

}
