﻿using Unreal.Core.Attributes;
using Unreal.Core.Models.Enums;

namespace FortniteReplayReader.Models.NetFieldExports.Weapons;

[NetFieldExportClassNetCache("B_Prj_Athena_FragGrenade_C_ClassNetCache", minimalParseMode: ParseMode.Debug)]
public class FragGrenadeCache : BaseExplosion
{
}
