﻿using Unreal.Core;
using Unreal.Core.Contracts;

namespace FortniteReplayReader.Models.NetFieldExports;

/// <summary>
/// 
/// </summary>
public class FQuantizedBuildingAttribute : IProperty
{
    public void Serialize(NetBitReader reader)
    {
        //throw new NotImplementedException();
    }
}
