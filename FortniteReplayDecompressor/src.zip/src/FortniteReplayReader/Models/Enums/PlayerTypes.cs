﻿namespace FortniteReplayReader.Models.Enums;

public enum PlayerTypes
{
    BOT = 0x03,
    NAMED_BOT = 0x10,
    PLAYER = 0x11
}
