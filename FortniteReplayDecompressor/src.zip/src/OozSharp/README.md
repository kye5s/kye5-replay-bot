# Ooz

C# version of the library by [powzix](https://github.com/powzix/ooz), converted for Fortnite by [SL-x-TnT](https://github.com/SL-x-TnT).
