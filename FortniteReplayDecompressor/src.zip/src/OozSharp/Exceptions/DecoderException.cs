﻿using System;

namespace OozSharp.Exceptions;

public class DecoderException : Exception
{
    public DecoderException(string message) : base(message)
    {

    }
}
