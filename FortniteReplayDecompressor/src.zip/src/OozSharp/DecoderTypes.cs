﻿namespace OozSharp;

public enum DecoderTypes : uint
{
    LZH = 1,
    LZHLW,
    LZNIB,
    None,
    LZB16,
    LZBLW,
    LZA,
    LZNA,
    Kraken,
    Mermaid,
    BitKnit,
    Selkie,
    Akkorokamui
}
