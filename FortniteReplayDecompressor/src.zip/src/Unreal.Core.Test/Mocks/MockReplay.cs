﻿using Unreal.Core.Models;

namespace Unreal.Core.Test.Mocks;

public class MockReplay : Replay
{
}
