﻿namespace Unreal.Core.Models.Enums;

public enum FBitArchiveEndIndex
{
    BUNCH,
    CONTENT_BLOCK_PAYLOAD,
    FIELD_HEADER_PAYLOAD,
    READ_ARRAY_FIELD,
}
