﻿namespace Unreal.Core.Models;

/// <summary>
/// see 
/// </summary>
public class ReplayDataInfo
{
    public uint Start { get; set; }
    public uint End { get; set; }
    public int Length { get; set; }
}
