﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unreal.Core.Test")]